# imghst
***

A simple and fast image hoster for applications like ShareX.

***

### What does it do?
***
Literally just upload files. That's it. 

### How to configure?
***
``imghst -h``


## How to Install?

```
pip install imghst
```
